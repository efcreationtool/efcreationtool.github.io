﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppRolePrivileges
{
    class Program
    {
        public static void Main(string[] args)
        {
            #region Data from App.Config
            string sCRMURL = ConfigurationManager.AppSettings["crmServerURL"].ToString();
            string sUserName = ConfigurationManager.AppSettings["crmUserName"];
            string sPassword = ConfigurationManager.AppSettings["crmPassword"];

            Console.WriteLine("CRM URL :: " + sCRMURL);
            Console.WriteLine("User Name :: " + sUserName + Environment.NewLine);
            #endregion Data from App.Config

            #region Local Variable Initialization
            IOrganizationService objService = null;
            Guid gUserId = new Guid();
            bool isUserAbleToLogin = false;
            #endregion Local Variable Initialization

            try
            {
                objService = GetCRMOrgService(sCRMURL, sUserName, sPassword,
                    ref gUserId, ref isUserAbleToLogin);
                if (isUserAbleToLogin)
                {
                    Console.WriteLine("User Logged-In...");
                    Console.WriteLine("User ID :: " + gUserId);
                }

                GetLoggedInUserDetails(gUserId, objService);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error ---> " + ex.Message);
            }
            finally
            {
                Console.WriteLine(Environment.NewLine + "Press Enter to exit....");
                Console.ReadKey();
            }
        }

        private static void GetLoggedInUserDetails(Guid gUserId, IOrganizationService objService)
        {
            #region Local Variable Initialization
            Entity eUser = null;
            #endregion Local Variable Initialization
            try
            {
                eUser = objService.Retrieve("systemuser", gUserId, new ColumnSet("systemuserid", "fullname"));
                if (eUser != null && eUser is Entity)
                {
                    if (eUser.Attributes.Contains("fullname") && eUser.Attributes["fullname"] != null)
                    {
                        Console.WriteLine("User Full Name is :: " +
                            eUser.GetAttributeValue<string>("fullname"));
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.InnerException != null ? ex.InnerException.Message : ex.Message);
            }
        }

        private static IOrganizationService GetCRMOrgService(string sCRMURL,
            string sUserName, string sPassword, ref Guid gUserId, ref bool isUserAbleToLogIn)
        {
            #region Local Variable Initialization
            IOrganizationService objService = null;
            gUserId = Guid.Empty;
            isUserAbleToLogIn = false;
            #endregion Local Variable Initialization
            try
            {
                Uri objCrmUrl = new Uri(sCRMURL);

                ClientCredentials objCredintials = new ClientCredentials();
                objCredintials.UserName.UserName = sUserName;
                objCredintials.UserName.Password = sPassword;
                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                OrganizationServiceProxy objServiceProxy =
                    new OrganizationServiceProxy(objCrmUrl, null, objCredintials, null);

                objService = (IOrganizationService)objServiceProxy;
                gUserId = ((WhoAmIResponse)objService.Execute(new WhoAmIRequest())).UserId;
                isUserAbleToLogIn = true;
                return objService;
            }
            catch (Exception ex)
            {
                throw new Exception("Log-in unsuccessful :: Please provide Valid Credentials or " +
                    "contact System Administrator.");
            }
        }
    }
}
